exports.themeLocation = './yadea-theme/';
exports.urlToPreview = 'http://localhost/yadea';
